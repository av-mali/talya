// Bu betik SADECE avukat.uyap.gov.tr sayfalarında çalışır.
// Ne yapar: sayfadaki görünen metni okur, Talya'nın backend'ine gönderir.
// Hiçbir veri, kullanıcının Talya'da "onayla" demesi olmadan kalıcı
// olarak kaydedilmez — bu betik sadece "ham metni ilet" işini yapar.

const TALYA_BASE = 'https://app.talyahukuk.com';

// "Toplu Takvime Ekle" gibi butonların ürettiği .ics dosyasını yakalamak
// için sayfanın kendi JS ortamına küçük bir script enjekte ediyoruz.
// Bkz: inject.js
(function injectIcsHook() {
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('inject.js');
  script.onload = function () { this.remove(); };
  (document.head || document.documentElement).appendChild(script);
})();

let lastCapturedIcs = null;

window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  if (event.data && event.data.source === 'talya-ics-hook' && event.data.icsText) {
    lastCapturedIcs = event.data.icsText;
    // Kullanıcı zaten "Toplu Takvime Ekle"ye tıkladı (kendi takvimi için).
    // Aynı anda, sessizce Talya'ya da gönderelim — ekstra bir işlem gerekmez.
    syncText(lastCapturedIcs);
  }
});

function extractPageText() {
  // UYAP'ın tam sayfa yapısını bilmediğimiz için (ve arayüz zamanla
  // değişebileceği için) en dayanıklı yöntem: tüm görünen metni almak,
  // ayrıştırmayı sunucu tarafında Claude'a bırakmak. Bu, .ics yakalanamayan
  // sayfalar için YEDEK yöntemdir.
  return document.body.innerText.replace(/\n{3,}/g, '\n\n').trim();
}

function showBanner(message, isError, onClickUrl) {
  let banner = document.getElementById('talya-sync-banner');
  if (!banner) {
    banner = document.createElement('div');
    banner.id = 'talya-sync-banner';
    banner.style.cssText = `
      position:fixed; bottom:20px; right:20px; z-index:999999;
      background:${isError ? '#B03A34' : '#1a1714'}; color:#fff;
      padding:12px 16px; border-radius:10px; font-family:sans-serif;
      font-size:13px; box-shadow:0 8px 24px rgba(0,0,0,.25); max-width:320px;
      display:flex; align-items:center; gap:10px; cursor:default;
    `;
    document.body.appendChild(banner);
  }
  banner.style.background = isError ? '#B03A34' : '#1a1714';
  banner.innerHTML = '';

  const text = document.createElement('span');
  text.textContent = message;
  banner.appendChild(text);

  if (onClickUrl) {
    const link = document.createElement('a');
    link.textContent = 'Onay Ekranını Aç →';
    link.href = onClickUrl;
    link.target = '_blank';
    link.style.cssText = 'color:#e8c874;font-weight:600;text-decoration:none;white-space:nowrap;';
    banner.appendChild(link);
  }

  const close = document.createElement('span');
  close.textContent = '✕';
  close.style.cssText = 'cursor:pointer;opacity:.6;margin-left:4px;';
  close.onclick = () => banner.remove();
  banner.appendChild(close);

  clearTimeout(banner._hideTimer);
  banner._hideTimer = setTimeout(() => banner.remove(), 20000);
}

async function syncText(text) {
  const { syncToken } = await chrome.storage.local.get(['syncToken']);
  if (!syncToken) {
    showBanner('Talya: Senkronizasyon anahtarı ayarlanmamış. Eklenti simgesine tıklayıp anahtarını gir.', true);
    return { ok: false, error: 'Anahtar yok.' };
  }
  if (!text || text.length < 10) {
    return { ok: false, error: 'Okunacak yeterli veri yok.' };
  }

  try {
    const res = await fetch(`${TALYA_BASE}/api/uyap-sync`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${syncToken}`,
      },
      body: JSON.stringify({ text }),
    });
    const data = await res.json();
    if (!res.ok) {
      showBanner(`Talya: ${data.error || 'Senkronizasyon başarısız.'}`, true);
      return { ok: false, error: data.error };
    }
    if (!data.itemCount) {
      showBanner('Talya: Aktarılacak bir dosya/duruşma bulunamadı.', false);
      return { ok: true, itemCount: 0 };
    }
    const importUrl = `${TALYA_BASE}/dashboard/uyap-import?batch=${data.batchId}`;
    showBanner(`Talya: ${data.itemCount} kayıt bulundu.`, false, importUrl);
    return { ok: true, itemCount: data.itemCount };
  } catch (e) {
    showBanner('Talya: Bağlantı hatası.', true);
    return { ok: false, error: 'Bağlantı hatası.' };
  }
}

// Elle/otomatik tetiklenen genel senkronizasyon — .ics yakalanmışsa onu,
// yoksa yedek olarak sayfanın görünen metnini kullanır.
async function runSync() {
  const text = lastCapturedIcs || extractPageText();
  return syncText(text);
}

// Popup'tan "şimdi senkronize et" komutu gelirse.
// ══════════════════════════════════════════════════════
// DOSYADAKİ TÜM BELGELERİ İNDİR
// UYAP'ın belge listesindeki "indir" ikonları gerçek bağlantı (<a href>)
// değil, tıklanınca kod çalıştıran butonlar. Bu ikonun görsel deseni
// (SVG path'i) her belgede aynı ve eşsiz olduğu için, sayfadaki tüm
// indirme ikonlarını bulup senin yerine teker teker "tıklıyoruz" —
// her belge normal indirme yoluyla bilgisayarına iniyor. Hiçbir şey
// Talya'ya veya başka bir yere gönderilmez, sadece kendi bilgisayarına iner.
// ══════════════════════════════════════════════════════
const DOWNLOAD_ICON_PATH = "M5 20h14v-2H5zM19 9h-4V3H9v6H5l7 7z";

function findDownloadButtons() {
  const paths = Array.from(document.querySelectorAll("svg path"));
  const matches = paths.filter((p) => (p.getAttribute("d") || "").trim() === DOWNLOAD_ICON_PATH);
  const buttons = matches
    .map((p) => p.closest("button") || p.closest("[role='button']") || p.closest("svg")?.parentElement)
    .filter(Boolean);
  return Array.from(new Set(buttons));
}

async function downloadAllDocuments(onProgress) {
  const buttons = findDownloadButtons();
  if (!buttons.length) {
    return { ok: false, error: "Bu sayfada belge indirme ikonu bulunamadı. Önce bir dosyanın 'Evrak' sekmesinde olduğundan emin ol." };
  }
  let count = 0;
  for (const btn of buttons) {
    try {
      btn.click();
      count++;
      if (onProgress) onProgress(count, buttons.length);
    } catch (e) { /* bu belgeyi atla, devam et */ }
    // Tarayıcıyı/sunucuyu boğmamak için belgeler arasında kısa bir bekleme.
    await new Promise((r) => setTimeout(r, 900));
  }
  return { ok: true, count, total: buttons.length };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'TALYA_MANUAL_SYNC') {
    runSync().then(sendResponse);
    return true; // asenkron cevap için
  }
  if (msg.type === 'TALYA_DOWNLOAD_ALL_DOCS') {
    downloadAllDocuments().then(sendResponse);
    return true; // asenkron cevap için
  }
});

// Otomatik senkronizasyon açıksa, sayfa yüklendikten kısa bir süre sonra
// (UYAP'ın kendi içeriğinin oturması için) sessizce bir kez çalıştır.
chrome.storage.local.get(['autoSync'], (data) => {
  if (data.autoSync) {
    setTimeout(runSync, 2500);
  }
});
