# Talya UYAP Senkronizasyon Eklentisi

Bu, UYAP Avukat Portalı'ndaki dosya/duruşma bilgilerini otomatik olarak
Talya hesabına aktaran bir Chrome eklentisidir. Henüz Chrome Web Store'da
yayınlanmadı — şimdilik "geliştirici modu" ile kendi tarayıcına kuracaksın.

## Kurulum (5 dakika)

1. Chrome'da adres çubuğuna şunu yaz: `chrome://extensions`
2. Sağ üstteki **"Geliştirici modu" (Developer mode)** anahtarını aç.
3. **"Paketlenmemiş öğe yükle" (Load unpacked)** butonuna tıkla.
4. Açılan pencerede bu klasörü (`talya-uyap-extension`) seç.
5. Eklenti listede görünecek — tarayıcının sağ üstünde bir simge belirir.

## Talya ile eşleştirme

1. Talya'da `app.talyahukuk.com` sitesine gir, **UYAP Entegrasyonu → Eklenti Bağlantısı**'na tıkla.
2. **"Anahtar Oluştur"** de, çıkan uzun metni (tly_ ile başlayan) kopyala.
3. Tarayıcıda eklenti simgesine tıkla, açılan küçük pencereye bu anahtarı yapıştır, **Kaydet** de.
4. İstersen "UYAP'a her girişimde otomatik senkronize et" kutucuğunu işaretle.

## Kullanım

- **En güvenilir yol — "Toplu Takvime Ekle":** UYAP'ın Duruşma Sorgulama
  sayfasında bu butona tıkladığında (kendi takvimin için indirdiğin dosya),
  eklenti aynı anda sessizce bir kopyasını yakalayıp Talya'ya gönderir.
  Bu dosya standart ve düzenli olduğu için AI'a bile gerek kalmadan,
  kesin kurallarla okunur — en hızlı ve en güvenilir yöntem budur.
- **Otomatik mod (yedek yöntem):** UYAP Avukat Portalı'na her girdiğinde,
  eklenti birkaç saniye sonra sessizce sayfanın görünen metnini okuyup
  Talya'ya gönderir (Claude ile ayrıştırılır). "Toplu Takvime Ekle"
  bulunmayan sayfalarda devreye giren yedek yöntemdir.
- **Elle mod:** UYAP sayfasındayken eklenti simgesine tıkla, **"Şimdi Senkronize Et"** de.

Her iki durumda da sağ altta küçük bir bildirim çıkar; "Onay Ekranını Aç"
linkine tıklarsan Talya'da bulunan kayıtları gözden geçirip onaylayabilirsin.

## Bir Dosyadaki Tüm Belgeleri İndirme

Bu özellik Talya'ya hiçbir şey göndermez — sadece kendi bilgisayarına, normal
"İndirilenler" klasörüne belgeleri tek tek indirir.

1. UYAP'ta bir dosyanın **"Evrak"** sekmesine gir (belge listesinin göründüğü ekran).
2. Eklenti simgesine tıkla, **"Bu Dosyadaki Tüm Belgeleri İndir"** de.
3. Eklenti, sayfadaki tüm belgeleri sırayla (aralarında kısa bir bekleme ile) indirir.

**Önemli:** Chrome, arka arkaya birden fazla dosya indirilmeye çalışıldığını
fark edince "Bu site birden fazla dosya indirmeye çalışıyor" diye bir uyarı
gösterebilir — çıkarsa **"İzin Ver" (Allow)** demen yeterli, tek seferlik bir onaydır.

## Önemli Notlar

- Eklenti, e-imzana veya UYAP şifrene **hiçbir zaman erişmez** — sadece zaten görüntülediğin sayfanın metnini okur.
- Hiçbir veri, Talya'daki onay ekranında **sen "Onayla ve Kaydet" demeden** kalıcı olarak kaydedilmez.
- UYAP arayüzü güncellenirse eklentinin okuma kalitesi etkilenebilir — böyle bir durumda haber ver, birlikte düzeltiriz.
