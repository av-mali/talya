// Bu dosya UYAP sayfasının KENDİ JavaScript ortamına enjekte edilir
// (content script'in izole dünyasında değil). Amacı: "Toplu Takvime Ekle"
// gibi butonlar bir .ics dosyasını tarayıcı içinde (Blob olarak) üretip
// indirttiğinde, o dosyanın içeriğini indirme gerçekleşmeden hemen önce
// yakalayıp content script'e iletmek. Hiçbir ağ isteği değiştirilmez,
// sadece zaten oluşturulan dosyanın bir kopyası okunur.

(function () {
  if (window.__talyaIcsHooked) return;
  window.__talyaIcsHooked = true;

  const originalCreateObjectURL = URL.createObjectURL.bind(URL);

  URL.createObjectURL = function (blob) {
    try {
      if (blob && typeof blob.text === "function" && blob.size > 0 && blob.size < 2_000_000) {
        blob
          .text()
          .then((text) => {
            if (typeof text === "string" && text.trim().startsWith("BEGIN:VCALENDAR")) {
              window.postMessage({ source: "talya-ics-hook", icsText: text }, "*");
            }
          })
          .catch(() => {});
      }
    } catch (e) {
      /* sessizce geç — asıl indirme işlemini asla engelleme */
    }
    return originalCreateObjectURL(blob);
  };
})();
