const tokenEl = document.getElementById('token');
const autoSyncEl = document.getElementById('autoSync');
const statusEl = document.getElementById('status');

// Kayıtlı ayarları yükle.
chrome.storage.local.get(['syncToken', 'autoSync'], (data) => {
  if (data.syncToken) tokenEl.value = data.syncToken;
  autoSyncEl.checked = !!data.autoSync;
});

document.getElementById('saveBtn').addEventListener('click', () => {
  const token = tokenEl.value.trim();
  chrome.storage.local.set({ syncToken: token, autoSync: autoSyncEl.checked }, () => {
    statusEl.textContent = 'Kaydedildi.';
    statusEl.className = 'status ok';
  });
});

document.getElementById('syncNowBtn').addEventListener('click', async () => {
  statusEl.textContent = 'Senkronize ediliyor…';
  statusEl.className = 'status';

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !tab.url.includes('uyap.gov.tr')) {
    statusEl.textContent = 'Önce UYAP Avukat Portalı sekmesine geç.';
    statusEl.className = 'status err';
    return;
  }

  chrome.tabs.sendMessage(tab.id, { type: 'TALYA_MANUAL_SYNC' }, (response) => {
    if (chrome.runtime.lastError) {
      statusEl.textContent = 'Sayfa ile bağlantı kurulamadı, sayfayı yenileyip tekrar dene.';
      statusEl.className = 'status err';
      return;
    }
    if (response && response.ok) {
      statusEl.textContent = 'Gönderildi — yeni sekmede onay ekranı açılacak.';
      statusEl.className = 'status ok';
    } else {
      statusEl.textContent = (response && response.error) || 'Bir hata oluştu.';
      statusEl.className = 'status err';
    }
  });
});

document.getElementById('downloadDocsBtn').addEventListener('click', async () => {
  statusEl.textContent = 'Belgeler indiriliyor, sayfadan ayrılma…';
  statusEl.className = 'status';

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !tab.url.includes('uyap.gov.tr')) {
    statusEl.textContent = 'Önce UYAP Avukat Portalı sekmesine geç.';
    statusEl.className = 'status err';
    return;
  }

  chrome.tabs.sendMessage(tab.id, { type: 'TALYA_DOWNLOAD_ALL_DOCS' }, (response) => {
    if (chrome.runtime.lastError) {
      statusEl.textContent = 'Sayfa ile bağlantı kurulamadı, sayfayı yenileyip tekrar dene.';
      statusEl.className = 'status err';
      return;
    }
    if (response && response.ok) {
      statusEl.textContent = `${response.count} belge indirme işlemi başlatıldı.`;
      statusEl.className = 'status ok';
    } else {
      statusEl.textContent = (response && response.error) || 'Bir hata oluştu.';
      statusEl.className = 'status err';
    }
  });
});
